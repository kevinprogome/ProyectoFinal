
    function changeLanguage(select) {
        var language = select.options[select.selectedIndex].value;
        var currentUrl = window.location.href;

        // Eliminar el parámetro lang si ya existe en la URL
        var updatedUrl = currentUrl.replace(/[\?&]lang=[^\?&]*/, '');

        // Agregar el nuevo parámetro lang a la URL
        updatedUrl += (updatedUrl.indexOf('?') !== -1 ? '&' : '?') + 'lang=' + language;

        // Redirigir a la URL actualizada
        window.location.href = updatedUrl;
    }
    
    var swiper = new Swiper(".slide-content", {
    slidesPerView: 3,
    spaceBetween: 25,
    loop: true,
    centerSlide: 'true',
    fade: 'true',
    grabCursor:'true',
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
      dynamicBullets: true,
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },

    breakpoints:{
        0:{
            slidesPerView: 1,
        },
        520:{
            slidesPerView: 2,
        },
        950:{
            slidesPerView: 3,
        },
    },
  });