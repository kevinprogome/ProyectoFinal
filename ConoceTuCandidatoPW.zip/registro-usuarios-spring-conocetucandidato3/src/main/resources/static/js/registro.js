function changeLanguage(language) {
    window.location.href = '/registro?lang=' + language;
}

 window.addEventListener("scroll", () => {
const indicatorBar = document.querySelector(".scroll-indicator-bar");
const pageScroll = document.body.scrollTop || document.documentElement.scrollTop;
const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
const scrollValue = (pageScroll / height) * 100;

indicatorBar.style.width = scrollValue + "%";
});

const menuBtn = document.querySelector(".nav-menu-btn");
const closeBtn = document.querySelector(".nav-close-btn");
const navigation = document.querySelector(".navigation");

menuBtn.addEventListener("click", () =>{
navigation.classList.add("active");
});

closeBtn.addEventListener("click", () =>{
navigation.classList.remove("active");
})

 var nombreRegex = /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s-]{2,}$/;
    var apellidoRegex = /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s-]{2,}$/;
    var emailRegex = /^([a-z0-9_\.\+-]+)@([\da-z\.-]+)\.([a-z\.]{2,6})$/;
    var passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])([A-Za-z\d$@$!%*?&]|[^ ]){8,}$/;



    function validarFormulario() {
        var nombre = document.getElementById("nombre").value;
        var apellido = document.getElementById("apellido").value;
        var email = document.getElementById("email").value;
        var password = document.getElementById("password").value;

        if (!nombre.match(nombreRegex)) {
            alert("El nombre es inválido.");
            return false;
        }

        if (!apellido.match(apellidoRegex)) {
            alert("El apellido es inválido.");
            return false;
        }

        if (!email.match(emailRegex)) {
            alert("El correo electrónico es inválido.");
            return false;
        }

         if (!password.match(passwordRegex)) {
        alert("La contraseña debe tener:\n" +
            "Mínimo 8 caracteres\n" +
            "Al menos una letra mayúscula\n" +
            "Al menos una letra minúscula\n" +
            "Al menos un dígito\n" +
            "No espacios en blanco\n" +
            "Al menos 1 caracter especial: $@$!%*?&");
        return false;
    }

        return true;
    }