package com.registro.usuarios;

import java.util.Locale;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

/**
 * Configuración de internacionalización (i18n) para la aplicación. Esta clase
 * implementa la interfaz {@link WebMvcConfigurer} para personalizar la
 * configuración de Spring MVC.
 */

@Configuration
public class i18n implements WebMvcConfigurer {
	/**
	 * Bean para resolver la configuración regional (locale) de la aplicación
	 * utilizando el mecanismo de sesión.
	 * 
	 * @return Un {@link SessionLocaleResolver} configurado con el locale
	 *         predeterminado como {@link Locale#US}.
	 */

	@Bean
	public LocaleResolver localeResolver() {
		SessionLocaleResolver sessionLocaleResolver = new SessionLocaleResolver();
		sessionLocaleResolver.setDefaultLocale(Locale.US);
		return sessionLocaleResolver;
	}

	/**
	 * Bean para el interceptor que permite cambiar dinámicamente la configuración
	 * regional (locale) de la aplicación.
	 * 
	 * @return Un {@link LocaleChangeInterceptor} configurado con el nombre del
	 *         parámetro como "lang".
	 */
	@Bean
	public LocaleChangeInterceptor localeChangeInterceptor() {
		LocaleChangeInterceptor localeChangeInterceptor = new LocaleChangeInterceptor();
		localeChangeInterceptor.setParamName("lang");
		return localeChangeInterceptor;
	}

	/**
	 * Agrega el interceptor de cambio de locale al registro de interceptores de la
	 * aplicación.
	 * 
	 * @param registry El registro de interceptores de Spring MVC.
	 */
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(localeChangeInterceptor());
	}

}
