package com.registro.usuarios.controlador;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.registro.usuarios.controlador.dto.UsuarioRegistroDTO;
import com.registro.usuarios.servicio.UsuarioServicio;

/**
 * Controlador para la gestión de registros de usuarios. Maneja las solicitudes
 * relacionadas con el registro de nuevos usuarios.
 */
@Controller
@RequestMapping("/registro")
public class RegistroUsuarioControlador {

	private UsuarioServicio usuarioServicio;

	/**
	 * Constructor del controlador que recibe un servicio de usuario como
	 * dependencia.
	 *
	 * @param usuarioServicio El servicio de usuario utilizado para el registro.
	 */

	public RegistroUsuarioControlador(UsuarioServicio usuarioServicio) {
		super();
		this.usuarioServicio = usuarioServicio;
	}

	/**
	 * Retorna un nuevo objeto {@link UsuarioRegistroDTO} para su uso en formularios
	 * de registro.
	 *
	 * @return Un nuevo objeto {@link UsuarioRegistroDTO}.
	 */
	@ModelAttribute("usuario")
	public UsuarioRegistroDTO retornarNuevoUsuarioRegistroDTO() {
		return new UsuarioRegistroDTO();
	}

	/**
	 * Maneja la solicitud para mostrar la página de inicio del registro de
	 * usuarios.
	 *
	 * @return La vista "inicio".
	 */

	@GetMapping("/inicio")
	public String mostrarPaginaInicio() {
		return "inicio";
	}

	/**
	 * Maneja la solicitud para mostrar el formulario de registro de usuarios.
	 *
	 * @return La vista "registro".
	 */
	@GetMapping
	public String mostrarFormularioDeRegistro() {
		return "registro";
	}

	/**
	 * Maneja la solicitud para registrar la cuenta de un nuevo usuario.
	 *
	 * @param registroDTO El objeto {@link UsuarioRegistroDTO} que contiene los
	 *                    datos del nuevo usuario.
	 * @return Redirecciona a la página de registro con un parámetro de éxito.
	 */
	@PostMapping
	public String registrarCuentaDeUsuario(@ModelAttribute("usuario") UsuarioRegistroDTO registroDTO) {
		usuarioServicio.guardar(registroDTO);
		return "redirect:/registro?exito";
	}

}
