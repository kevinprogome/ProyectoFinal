package com.registro.usuarios.repositorio;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.registro.usuarios.modelo.Usuario;

/**
 * Interfaz que define métodos de acceso a datos para la entidad Usuario en la
 * base de datos. Extiende JpaRepository, proporcionando operaciones CRUD
 * estándar.
 */
@Repository
public interface UsuarioRepositorio extends JpaRepository<Usuario, Long> {
	/**
	 * Busca y recupera un usuario por su dirección de correo electrónico.
	 *
	 * @param email La dirección de correo electrónico del usuario a buscar.
	 * @return El usuario correspondiente a la dirección de correo electrónico
	 *         proporcionada.
	 */
	public Usuario findByEmail(String email);

	/**
	 * Busca y recupera una lista de usuarios que han votado por un candidato
	 * específico.
	 *
	 * @param candidato El candidato por el cual se filtran los usuarios.
	 * @return Una lista de usuarios que han votado por el candidato especificado.
	 */
	public List<Usuario> findByCandidato(String candidato);

}
