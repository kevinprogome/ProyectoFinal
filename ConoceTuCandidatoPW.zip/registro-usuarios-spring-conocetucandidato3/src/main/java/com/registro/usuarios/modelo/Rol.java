package com.registro.usuarios.modelo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Clase de entidad que representa el modelo de un rol en el sistema. Se utiliza
 * para almacenar información sobre los roles de los usuarios en la base de
 * datos.
 */
@Entity
@Table(name = "rol")
public class Rol {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String nombre;

	/**
	 * Obtiene el identificador único del rol.
	 *
	 * @return El identificador único del rol.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Establece el identificador único del rol.
	 *
	 * @param id El nuevo identificador único del rol.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Obtiene el nombre del rol.
	 *
	 * @return El nombre del rol.
	 */

	public String getNombre() {
		return nombre;
	}

	/**
	 * Establece el nombre del rol.
	 *
	 * @param nombre El nuevo nombre del rol.
	 */

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * Constructor que inicializa un objeto Rol con valores específicos.
	 *
	 * @param id     El identificador único del rol.
	 * @param nombre El nombre del rol.
	 */
	public Rol(Long id, String nombre) {
		super();
		this.id = id;
		this.nombre = nombre;
	}

	/**
	 * Constructor por defecto necesario para la serialización/deserialización de
	 * objetos.
	 */

	public Rol() {

	}

	/**
	 * Constructor que inicializa un objeto Rol con un nombre específico.
	 *
	 * @param nombre El nombre del rol.
	 */
	public Rol(String nombre) {
		super();
		this.nombre = nombre;
	}

}
