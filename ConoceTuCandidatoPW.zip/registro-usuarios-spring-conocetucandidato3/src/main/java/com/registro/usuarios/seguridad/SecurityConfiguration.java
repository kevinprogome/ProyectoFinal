package com.registro.usuarios.seguridad;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.registro.usuarios.servicio.UsuarioServicio;

/**
 * Configuración de seguridad para la aplicación. Extiende
 * WebSecurityConfigurerAdapter para personalizar la configuración de seguridad.
 */
@Configuration
@EnableWebSecurity
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

	@Autowired
	private UsuarioServicio usuarioServicio;

	/**
	 * Configura el codificador de contraseñas utilizado por la aplicación.
	 *
	 * @return Un bean BCryptPasswordEncoder para codificar contraseñas.
	 */
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	/**
	 * Configura el proveedor de autenticación personalizado.
	 *
	 * @return Un bean DaoAuthenticationProvider configurado con el servicio de
	 *         usuarios y el codificador de contraseñas.
	 */
	@Bean
	public DaoAuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider auth = new DaoAuthenticationProvider();
		auth.setUserDetailsService(usuarioServicio);
		auth.setPasswordEncoder(passwordEncoder());
		return auth;
	}

	/**
	 * Configura la autenticación para el proveedor personalizado.
	 *
	 * @param auth El AuthenticationManagerBuilder utilizado para construir la
	 *             configuración de autenticación.
	 * @throws Exception Si ocurre un error al configurar la autenticación.
	 */
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.authenticationProvider(authenticationProvider());
	}

	/**
	 * Configura la autorización y la autenticación para las solicitudes HTTP.
	 *
	 * @param http El objeto HttpSecurity utilizado para configurar la seguridad
	 *             HTTP.
	 * @throws Exception Si ocurre un error al configurar la seguridad HTTP.
	 */

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests()
				.antMatchers("/registro**", "/js/**", "/css/**", "/images/**", "/login**", "/candidatos**", "/inicio**",
						"/dagobertomarin**", "/edinsonamin**", "/germancasagua**", "/germandario**", "/hectorbotello**",
						"/jorgeandres**", "/wilkerbautista**", "/wilmarcharry**", "/yilbersaavedra**")
				.permitAll().anyRequest().authenticated().and().formLogin().loginPage("/login").permitAll().and()
				.logout().invalidateHttpSession(true).clearAuthentication(true)
				.logoutRequestMatcher(new AntPathRequestMatcher("/logout")).logoutSuccessUrl("/login?logout")
				.permitAll();
	}
}
