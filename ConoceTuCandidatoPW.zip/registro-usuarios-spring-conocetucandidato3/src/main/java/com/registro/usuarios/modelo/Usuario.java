package com.registro.usuarios.modelo;

import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * Clase de entidad que representa el modelo de un usuario en el sistema. Se
 * utiliza para almacenar información sobre los usuarios en la base de datos.
 */
@Entity
@Table(name = "usuarios", uniqueConstraints = @UniqueConstraint(columnNames = "email"))
public class Usuario {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "nombre")
	private String nombre;

	@Column(name = "apellido")
	private String apellido;

	@Column(name = "candidato")
	private String candidato;

	private String email;
	private String password;
	@Column(name = "votos")
	private Integer votos;

	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(name = "usuarios_roles", joinColumns = @JoinColumn(name = "usuario_id", referencedColumnName = "id"), inverseJoinColumns = @JoinColumn(name = "rol_id", referencedColumnName = "id"))
	private Collection<Rol> roles;

	/**
	 * Obtiene el identificador único del usuario.
	 *
	 * @return El identificador único del usuario.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Establece el identificador único del usuario.
	 *
	 * @param id El nuevo identificador único del usuario.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getCandidato() {
		return candidato;
	}

	public void setCandidato(String candidato) {
		this.candidato = candidato;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getVotos() {
		return votos;
	}

	public void setVotos(Integer votos) {
		this.votos = votos;
	}
	// Métodos getter y setter para los demás atributos...

	/**
	 * Obtiene la colección de roles asociados al usuario.
	 *
	 * @return La colección de roles asociados al usuario.
	 */
	public Collection<Rol> getRoles() {
		return roles;
	}

	/**
	 * Establece la colección de roles asociados al usuario.
	 *
	 * @param roles La nueva colección de roles asociados al usuario.
	 */
	public void setRoles(Collection<Rol> roles) {
		this.roles = roles;
	}

	/**
	 * Constructor que inicializa un objeto Usuario con valores específicos.
	 *
	 * @param id        El identificador único del usuario.
	 * @param nombre    El nombre del usuario.
	 * @param apellido  El apellido del usuario.
	 * @param candidato El candidato preferido del usuario.
	 * @param email     La dirección de correo electrónico del usuario.
	 * @param password  La contraseña del usuario.
	 * @param votos     El número de votos del usuario.
	 * @param roles     La colección de roles asociados al usuario.
	 */
	public Usuario(Long id, String nombre, String apellido, String candidato, String email, String password,
			Integer votos, Collection<Rol> roles) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.apellido = apellido;
		this.candidato = candidato;
		this.email = email;
		this.password = password;
		this.votos = votos;
		this.roles = roles;
	}

	/**
	 * Constructor que inicializa un objeto Usuario con valores específicos.
	 *
	 * @param nombre    El nombre del usuario.
	 * @param apellido  El apellido del usuario.
	 * @param candidato El candidato preferido del usuario.
	 * @param email     La dirección de correo electrónico del usuario.
	 * @param password  La contraseña del usuario.
	 * @param votos     El número de votos del usuario.
	 * @param roles     La colección de roles asociados al usuario.
	 */

	public Usuario(String nombre, String apellido, String candidato, String email, String password, Integer votos,
			Collection<Rol> roles) {
		super();
		this.nombre = nombre;
		this.apellido = apellido;
		this.candidato = candidato;
		this.email = email;
		this.password = password;
		this.votos = votos;
		this.roles = roles;
	}

	/**
	 * Constructor por defecto necesario para la serialización/deserialización de
	 * objetos.
	 */
	public Usuario() {
		super();
	}

}
