package com.registro.usuarios.servicio;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.registro.usuarios.controlador.dto.UsuarioRegistroDTO;
import com.registro.usuarios.modelo.Usuario;

/**
 * Interfaz que define operaciones de servicio relacionadas con la entidad
 * Usuario. Extiende UserDetailsService para proporcionar integración con el
 * sistema de autenticación de Spring Security.
 */
public interface UsuarioServicio extends UserDetailsService {
	/**
	 * Guarda un nuevo usuario en el sistema a partir de la información
	 * proporcionada en el DTO de registro.
	 *
	 * @param registroDTO El DTO que contiene la información del usuario a ser
	 *                    registrado.
	 * @return El usuario registrado.
	 */
	public Usuario guardar(UsuarioRegistroDTO registroDTO);

	/**
	 * Calcula la suma total de votos para un candidato específico.
	 *
	 * @param candidato El nombre del candidato para el cual se calcula la suma de
	 *                  votos.
	 * @return La suma total de votos para el candidato especificado.
	 */
	int calcularSumaVotos(String candidato);

}
