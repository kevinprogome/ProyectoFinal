package com.registro.usuarios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Clase principal que inicia la aplicación Spring Boot para el registro de
 * usuarios con Spring Security. Esta clase utiliza la anotación
 * {@link SpringBootApplication} para habilitar la configuración automática de
 * Spring Boot.
 */
@SpringBootApplication
public class RegistroUsuariosSpringSecurityApplication {
	/**
	 * Método principal que inicia la aplicación Spring Boot. Configura el puerto
	 * del servidor mediante la propiedad del sistema y luego inicia la aplicación.
	 *
	 * @param args Los argumentos de línea de comandos pasados a la aplicación.
	 */

	public static void main(String[] args) {
		// Configura el puerto del servidor mediante la propiedad del sistema
		System.setProperty("server.port", "8082");
		// Inicia la aplicación Spring Boot

		SpringApplication.run(RegistroUsuariosSpringSecurityApplication.class, args);
	}

}
