package com.registro.usuarios.servicio;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.registro.usuarios.controlador.dto.UsuarioRegistroDTO;
import com.registro.usuarios.modelo.Rol;
import com.registro.usuarios.modelo.Usuario;
import com.registro.usuarios.repositorio.UsuarioRepositorio;

/**
 * Implementación del servicio de usuario que maneja la lógica de negocio
 * relacionada con los usuarios.
 */
@Service
public class UsuarioServicioImpl implements UsuarioServicio {

	private UsuarioRepositorio usuarioRepositorio;
	/**
	 * Codificador de contraseñas utilizado para cifrar las contraseñas de los
	 * usuarios. La anotación @Autowired se utiliza para inyectar automáticamente
	 * una instancia de BCryptPasswordEncoder.
	 */
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	/**
	 * Constructor de la clase que recibe el repositorio de usuarios como
	 * dependencia.
	 *
	 * @param usuarioRepositorio El repositorio de usuarios utilizado para acceder a
	 *                           la base de datos.
	 */

	public UsuarioServicioImpl(UsuarioRepositorio usuarioRepositorio) {
		super();
		this.usuarioRepositorio = usuarioRepositorio;
	}

	/**
	 * Guarda un nuevo usuario en la base de datos a partir de la información
	 * proporcionada en el DTO de registro.
	 *
	 * @param registroDTO El DTO que contiene la información del usuario a ser
	 *                    registrado.
	 * @return El usuario registrado.
	 */
	@Override
	public Usuario guardar(UsuarioRegistroDTO registroDTO) {
		Usuario usuario = new Usuario(registroDTO.getNombre(), registroDTO.getApellido(), registroDTO.getCandidato(),
				registroDTO.getEmail(), passwordEncoder.encode(registroDTO.getPassword()), registroDTO.getVotos(),
				Arrays.asList(new Rol("ROLE_USER")));
		return usuarioRepositorio.save(usuario);
	}

	/**
	 * Carga un usuario por su nombre de usuario (en este caso, la dirección de
	 * correo electrónico).
	 *
	 * @param username El nombre de usuario (correo electrónico) del usuario a
	 *                 cargar.
	 * @return Detalles del usuario para la autenticación de Spring Security.
	 * @throws UsernameNotFoundException Si el usuario no se encuentra en la base de
	 *                                   datos.
	 */
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Usuario usuario = usuarioRepositorio.findByEmail(username);
		if (usuario == null) {
			throw new UsernameNotFoundException("Usuario o password inválidos");
		}
		return new User(usuario.getEmail(), usuario.getPassword(), mapearAutoridadesRoles(usuario.getRoles()));
	}

	/**
	 * Convierte la colección de roles del usuario en una colección de autoridades
	 * de Spring Security.
	 *
	 * @param roles La colección de roles del usuario.
	 * @return Colección de autoridades de Spring Security.
	 */
	private Collection<? extends GrantedAuthority> mapearAutoridadesRoles(Collection<Rol> roles) {
		return roles.stream().map(role -> new SimpleGrantedAuthority(role.getNombre())).collect(Collectors.toList());
	}

	/**
	 * Calcula la suma total de votos para un candidato específico.
	 *
	 * @param candidato El nombre del candidato para el cual se calcula la suma de
	 *                  votos.
	 * @return La suma total de votos para el candidato especificado.
	 */

	@Override
	public int calcularSumaVotos(String candidato) {
		try {
			List<Usuario> usuarios = usuarioRepositorio.findByCandidato(candidato);

			if (usuarios != null) {
				return usuarios.size();
			} else {
				return 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

}
