package com.registro.usuarios.i18ncontrolador;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.support.RequestContextUtils;
import org.springframework.util.StringUtils;

/**
 * Controlador para gestionar la configuración de idioma (locale) en la página
 * de inicio de sesión. Permite cambiar el idioma de la aplicación y redirige a
 * la página de inicio de sesión después del cambio.
 */
@Controller
@RequestMapping("/login")
public class LocaleControllerLogin {
	/**
	 * Maneja la solicitud GET para la página de inicio de sesión.
	 *
	 * @param model El modelo utilizado para pasar datos a la vista.
	 * @return La vista "login".
	 */
	@GetMapping("/cambiarIdioma")
	public String loginPage(Model model) {
		return "login";
	}

	/**
	 * Maneja la solicitud GET para cambiar el idioma de la aplicación en la página
	 * de inicio de sesión.
	 *
	 * @param lang     El nuevo idioma seleccionado.
	 * @param request  La solicitud HTTP actual.
	 * @param response La respuesta HTTP actual.
	 * @return Redirecciona a la página de inicio de sesión después del cambio de
	 *         idioma.
	 */

	@GetMapping("/locale")
	public String changeLocaleGet(@RequestParam(name = "lang") String lang, HttpServletRequest request,
			HttpServletResponse response) {
		// Obtiene el resolvedor de locales y actualiza el idioma de la aplicación.
		LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver(request);
		if (localeResolver != null) {
			localeResolver.setLocale(request, response, StringUtils.parseLocaleString(lang));
		}
		return "redirect:/login";
	}

	/**
	 * Maneja la solicitud POST para cambiar el idioma de la aplicación en la página
	 * de inicio de sesión.
	 *
	 * @param lang     El nuevo idioma seleccionado.
	 * @param request  La solicitud HTTP actual.
	 * @param response La respuesta HTTP actual.
	 * @return Redirecciona a la página de inicio de sesión después del cambio de
	 *         idioma.
	 */
	@PostMapping("/locale")
	// Obtiene el resolvedor de locales y actualiza el idioma de la aplicación.

	public String changeLocalePost(@RequestParam(name = "lang") String lang, HttpServletRequest request,
			HttpServletResponse response) {
		LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver(request);
		if (localeResolver != null) {
			localeResolver.setLocale(request, response, StringUtils.parseLocaleString(lang));
		}
		return "redirect:/login";
	}
}
