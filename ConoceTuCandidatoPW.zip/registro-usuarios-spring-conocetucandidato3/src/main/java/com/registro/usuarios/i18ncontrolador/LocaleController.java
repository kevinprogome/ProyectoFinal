package com.registro.usuarios.i18ncontrolador;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.support.RequestContextUtils;
import org.springframework.util.StringUtils;

/**
 * Controlador para gestionar la configuración de idioma (locale) de la
 * aplicación mediante solicitudes HTTP. Permite cambiar el idioma de la
 * aplicación y redirige a la página principal después del cambio.
 */
@Controller
public class LocaleController {
	/**
	 * Maneja la solicitud GET para la página de configuración de idioma (locale).
	 *
	 * @return La vista "index".
	 */
	@RequestMapping("/locale")
	public String locale() {
		return "index";
	}

	/**
	 * Maneja la solicitud POST para cambiar el idioma de la aplicación.
	 *
	 * @param lang    El nuevo idioma seleccionado.
	 * @param request La solicitud HTTP actual.
	 * @return Redirecciona a la página principal después del cambio de idioma.
	 */

	@PostMapping("/locale")
	public String changeLocale(@RequestParam(name = "lang") String lang, HttpServletRequest request) {
		// Obtiene el resolvedor de locales y actualiza el idioma de la aplicación.

		LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver(request);
		if (localeResolver != null) {
			localeResolver.setLocale(request, null, StringUtils.parseLocaleString(lang));
		}
		return "redirect:/";
	}
}
