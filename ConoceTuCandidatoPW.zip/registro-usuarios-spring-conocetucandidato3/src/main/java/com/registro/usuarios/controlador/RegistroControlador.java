package com.registro.usuarios.controlador;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

import com.registro.usuarios.servicio.UsuarioServicio;

/**
 * Controlador para la gestión de la aplicación de registro de usuarios. Maneja
 * las solicitudes relacionadas con la autenticación, la página de inicio y la
 * visualización de candidatos.
 */

@Controller
public class RegistroControlador {

	@Autowired
	private UsuarioServicio servicio;

	/**
	 * Maneja la solicitud para la página de inicio de sesión.
	 *
	 * @param lang    El parámetro de idioma para la internacionalización.
	 * @param request La solicitud HTTP actual.
	 * @return La vista "login".
	 */
	@GetMapping("/login")
	public String iniciarSesion(@RequestParam(name = "lang", required = false) String lang,
			HttpServletRequest request) {
		if (lang != null) {
			request.getSession().setAttribute(SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME, new Locale(lang));
		}

		Locale currentLocale = (Locale) request.getSession()
				.getAttribute(SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME);
		System.out.println("Lang parameter: " + lang);
		System.out.println("Current Locale: " + currentLocale);

		return "login";
	}

	/**
	 * Maneja la solicitud para la página de inicio.
	 *
	 * @param modelo El modelo utilizado para pasar datos a la vista.
	 * @return La vista "index".
	 */

	@GetMapping("/")
	public String verPaginaDeInicio(Model modelo) {
		// Calcula y agrega atributos al modelo para su visualización en la vista.

		int sumaVotosAmin = servicio.calcularSumaVotos("Amin");
		modelo.addAttribute("sumaVotosAmin", sumaVotosAmin);

		int sumaVotosDagoberto = servicio.calcularSumaVotos("Dagoberto");
		modelo.addAttribute("sumaVotosDagoberto", sumaVotosDagoberto);

		int sumaVotosCasagua = servicio.calcularSumaVotos("Casagua");
		modelo.addAttribute("sumaVotosCasagua", sumaVotosCasagua);

		int sumaVotosChicho = servicio.calcularSumaVotos("Chicho");
		modelo.addAttribute("sumaVotosChicho", sumaVotosChicho);

		int sumaVotosBotello = servicio.calcularSumaVotos("Botello");
		modelo.addAttribute("sumaVotosBotello", sumaVotosBotello);

		int sumaVotosJorge = servicio.calcularSumaVotos("Jorge");
		modelo.addAttribute("sumaVotosJorge", sumaVotosJorge);

		int sumaVotosWilker = servicio.calcularSumaVotos("Wilker");
		modelo.addAttribute("sumaVotosWilker", sumaVotosWilker);

		int sumaVotosWilmar = servicio.calcularSumaVotos("Wilmar");
		modelo.addAttribute("sumaVotosWilmar", sumaVotosWilmar);

		int sumaVotosYilber = servicio.calcularSumaVotos("Yilber");
		modelo.addAttribute("sumaVotosYilber", sumaVotosYilber);

		return "index";
	}

	/**
	 * Maneja la solicitud para la página de inicio.
	 *
	 * @return La vista "inicio".
	 */
	@GetMapping("/inicio")
	public String mostrarPaginaInicio() {
		return "inicio";
	}

	@GetMapping("/dagobertomarin")
	public String mostrarCandidato1() {
		return "DagobertoMarin";
	}

	@GetMapping("/edinsonamin")
	public String mostrarCandidato2() {
		return "EdinsonAmin";
	}

	@GetMapping("/germancasagua")
	public String mostrarCandidato3() {
		return "GermanCasagua";
	}

	@GetMapping("/germandario")
	public String mostrarCandidato9() {
		return "GermanDario";
	}

	@GetMapping("/hectorbotello")
	public String mostrarCandidato4() {
		return "HectorBotello";
	}

	@GetMapping("/jorgeandres")
	public String mostrarCandidato5() {
		return "JorgeAndresGechem";
	}

	@GetMapping("/wilkerbautista")
	public String mostrarCandidato6() {
		return "WilkerBautista";
	}

	@GetMapping("/wilmarcharry")
	public String mostrarCandidato7() {
		return "WilmarCharry";
	}

	@GetMapping("/yilbersaavedra")
	public String mostrarCandidato8() {
		return "YilberSaavedra";
	}

	@GetMapping("/candidatos")
	public String mostrarPaginaCandidatos() {
		return "CandidatosDef";
	}

	/**
	 * Maneja la solicitud para cambiar el idioma de la aplicación.
	 *
	 * @param lang    El nuevo idioma seleccionado.
	 * @param request La solicitud HTTP actual.
	 * @return Redirecciona a la página de inicio.
	 */
	@RequestMapping("/cambiarLocale")
	public String changeLocale(@RequestParam("lang") String lang, HttpServletRequest request) {
		Locale locale = new Locale(lang);
		request.getSession().setAttribute(SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME, locale);
		return "redirect:/";
	}

}
